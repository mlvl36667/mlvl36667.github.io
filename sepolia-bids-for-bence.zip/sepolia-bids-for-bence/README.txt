Sepolia ePBS (Gloas) execution payload bids, exported 2026-11-23 by MigaLabs.

1. winning-bids-since-gloas.csv: one row per slot from the Gloas fork (slot 11296768, 2026-10-06
   13:53:36 UTC) to 2026-11-23, from our goteth indexer (t_block_metrics). The bid each proposer
   included:
   - proposed: false = missed slot (no bid fields)
   - builder_index: empty with self_build = 1 when the proposer built its own payload
   - bid_value_gwei: what the builder pays the proposer
   - execution_payment_gwei: the bid's execution payment field
   - payload_revealed: whether the builder revealed the payload (false = EMPTY slot)
   - el_*, gas_*, base_fee, transactions, fee_recipient: the execution payload of that slot
   - graffiti: the proposer's graffiti
   MigaLabs runs builder 12 (extra data rbuilder.migalabs.eth).

2. gossip-bids-captures.csv: every bid our beacon node received over gossip
   (execution_payload_bid events) in 6 capture windows (26 Oct to 9 Nov, 3,267 slots), losing
   bids included:
   - capture: window name
   - ms_before_slot_start: arrival at our node relative to the slot start (negative = after)
   - won_slot: 1 if it matches the included bid of that slot (builder and value)
   Caveat: a node only sees bids that pass gossip validation. Lighthouse ignores a bid that is not
   above the best one seen for the same slot and parent, and a second bid from the same builder
   for the same slot and parent. So this is what reached one node, not every bid ever sent.
   Builders 0, 7, 8, 9 and 10 share one operator (extra data builder.nflaig.eth).
